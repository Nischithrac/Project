﻿INSERT INTO [dbo].[Glossary] ([Product], [Quantity], [Price]) VALUES (N'sxsdc', N'mbb', N'bnb')
INSERT INTO [dbo].[Glossary] ([Product], [Quantity], [Price]) VALUES (N'bb', N'bmmn', N'bbcdc')
